from ByteStream.Writer import Writer

class LogicDecreaseHeroScoreCommand(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24111
        self.player = player

    def encode(self):
        self.writeVInt(205)
        self.writeInt(0)
        self.writeVInt(0)
        for x in range(0):
        	self.writeVInt(0)